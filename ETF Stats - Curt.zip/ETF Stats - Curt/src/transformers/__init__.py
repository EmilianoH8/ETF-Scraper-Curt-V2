# JP Morgan Asset Management Fund Scraper - Transformers Package
from .fund_transformer import FundTransformer

__all__ = ['FundTransformer'] 