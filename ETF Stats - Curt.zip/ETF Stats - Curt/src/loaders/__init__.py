# JP Morgan Asset Management Fund Scraper - Loaders Package
from .excel_loader import ExcelLoader

__all__ = ['ExcelLoader'] 